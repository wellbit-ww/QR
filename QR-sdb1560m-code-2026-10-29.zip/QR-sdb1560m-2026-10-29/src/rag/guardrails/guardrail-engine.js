const { validateAnswerAgainstContext } = require("../answer-validation");
const { validateSdb702nmAnswerAgainstContext } = require("../sdb702nm-answer-validation");
const { validateSdb302nmAnswerAgainstContext } = require("../sdb302nm-answer-validation");
const { validateSdb151nmAnswerAgainstContext } = require("../sdb151nm-answer-validation");
const { validateSdb1560mAnswerAgainstContext } = require("../sdb1560m-answer-validation");
const { shouldUseHonestRag, isNumericTtxRetrievalQuery } = require("../honest-rag-mode");
const { validateGrounding } = require("../synthesis/grounding-validation");
const {
  goldenNumericMismatchFailures,
  deterministicTopicMismatchFailures,
} = require("../sdb1106nm-golden-facts");
const { STRICT_ABSTAIN } = require("../prompts");
const { ragInfo, ragWarn } = require("../rag-log");

/** Контекст с именем материала + общеинженерный термин в ответе — не считаем «галлюцинацией» по слову. */
function isDocBackedMaterialParaphraseToken(wordLower, ctxLower) {
  if (!wordLower || wordLower.length < 4) {
    return false;
  }
  const docNamesMaterial =
    /цеолит|силикагел|zeolite|adsorb|молекулярн(?:ое|ого)\s+сито|поглощает\s+влагу|влагу\s+из\s+воздух/i.test(
      ctxLower
    );
  if (!docNamesMaterial) {
    return false;
  }
  return /абсорбент|адсорбент|сорбент|наполнител|химическ|веществ/i.test(wordLower);
}

function detectHallucinations(answer, retrievalContext) {
  const answerWords = String(answer || "")
    .toLowerCase()
    .match(/\p{L}{4,}/gu);
  if (!answerWords || answerWords.length === 0) {
    return { flagged: false, suspiciousTokens: [], ratio: 0 };
  }
  const ctxLower = String(retrievalContext || "").toLowerCase();
  const contextSet = new Set(
    (String(retrievalContext || "").toLowerCase().match(/\p{L}{4,}/gu) || []).map((w) => w.trim())
  );
  const uniqueAnswer = [...new Set(answerWords)];
  const suspicious = uniqueAnswer.filter((w) => {
    if (contextSet.has(w)) {
      return false;
    }
    return !isDocBackedMaterialParaphraseToken(w, ctxLower);
  });
  const ratio = suspicious.length / Math.max(1, uniqueAnswer.length);
  return {
    flagged: suspicious.length >= 14 && ratio > 0.28,
    suspiciousTokens: suspicious.slice(0, 25),
    ratio: Number(ratio.toFixed(3)),
  };
}

function validateForProfile(answer, retrievalContext, intent, hints = {}) {
  if (hints.validationProfile === "sdb702") {
    return validateSdb702nmAnswerAgainstContext(answer, retrievalContext, intent || {});
  }
  if (hints.validationProfile === "sdb302") {
    return validateSdb302nmAnswerAgainstContext(answer, retrievalContext, intent || {});
  }
  if (hints.validationProfile === "sdb151") {
    return validateSdb151nmAnswerAgainstContext(answer, retrievalContext, intent || {});
  }
  if (hints.validationProfile === "sdb1560") {
    return validateSdb1560mAnswerAgainstContext(answer, retrievalContext, intent || {});
  }
  const equipmentId = hints.equipmentId || intent?.equipmentId;
  if (
    shouldUseHonestRag(equipmentId) &&
    equipmentId === "sdb1560m" &&
    isNumericTtxRetrievalQuery(hints.originalQuery || intent?.originalQuery, intent)
  ) {
    return validateSdb1560mAnswerAgainstContext(answer, retrievalContext, intent || {});
  }
  return validateAnswerAgainstContext(answer, retrievalContext, intent || {});
}

function looksLikeAbstainPhrase(text) {
  return /информац(?:ия|ии)\s+.*отсутств|не\s+найден|недостаточно\s+данных/i.test(String(text || ""));
}

function isEffectivelyEmptyContext(retrievalContext) {
  const t = String(retrievalContext || "").trim();
  if (!t) {
    return true;
  }
  if (t === "Релевантный контекст не найден.") {
    return true;
  }
  if (t.length < 80) {
    return true;
  }
  return false;
}

function allowShapeFromModelText(text, reason, extras = {}) {
  const outputText = String(text ?? "");
  return {
    passed: true,
    success: true,
    outputText,
    action: "ALLOW",
    reason,
    preserveOriginalText: true,
    hallucination: { flagged: false, suspiciousTokens: [], ratio: 0 },
    base: { ok: true, warnings: [], failures: [] },
    grounding: { ok: true, warnings: [], failures: [] },
    ...extras,
  };
}

function abstainShape(reason, hallucination, base, grounding, extras = {}) {
  return {
    passed: false,
    success: false,
    outputText: null,
    action: "ABSTAIN",
    reason,
    preserveOriginalText: false,
    hallucination,
    base,
    grounding,
    ...extras,
  };
}

/**
 * @param {{
 *   answer: string,
 *   retrievalContext: string,
 *   intent?: object,
 *   hints?: {
 *     deliveryMethod?: string,
 *     semanticSimilarity?: number,
 *     semanticRescueThreshold?: number,
 *   },
 * }} params
 */
function runGuardrails({ answer, retrievalContext, intent, hints = {} }) {
  const deliveryMethod = hints.deliveryMethod || "standard";
  const semanticSimilarity = Math.max(
    0,
    Math.min(
      1,
      Number.isFinite(Number(hints.semanticSimilarity)) ? Number(hints.semanticSimilarity) : 0,
    ),
  );
  const semanticRescueThreshold = Math.max(
    0,
    Math.min(1, Number(hints.semanticRescueThreshold ?? 0.75)),
  );

  const trimmed = String(answer || "").trim();
  const textPresent = Boolean(trimmed) && trimmed !== STRICT_ABSTAIN;

  ragInfo("guardrails.enter", {
    deliveryMethod,
    semanticSimilarity,
    semanticRescueThreshold,
    textPresent,
    textLen: trimmed.length,
  });

  if (deliveryMethod === "safety_fallback") {
    ragInfo("guardrails.bypass", { method: "safety_plain_text_trust", deliveryMethod });
    return allowShapeFromModelText(answer, "safety_plain_text_bypass", {
      deliveryMethod,
      guardrailBypass: "safety_plain_text",
    });
  }

  if (deliveryMethod === "direct_deterministic" || deliveryMethod === "rag_deterministic") {
    const query = String(intent?.originalQuery || hints.originalQuery || "").trim();
    const intentForCheck = { ...intent, originalQuery: query || intent?.originalQuery };
    const topicFails = deterministicTopicMismatchFailures(
      trimmed,
      intentForCheck,
      query,
      hints.factKey,
    );
    const numericFails = goldenNumericMismatchFailures(trimmed, intentForCheck, query);
    const detFails = [...topicFails, ...numericFails];
    if (detFails.length > 0) {
      ragWarn("guardrails.deterministic_fail", {
        deliveryMethod,
        codes: detFails.map((f) => f.code),
        details: detFails.map((f) => f.detail).filter(Boolean),
      });
      return abstainShape(
        "deterministic_topic_or_numeric_mismatch",
        { flagged: false, suspiciousTokens: [], ratio: 0 },
        { ok: false, warnings: [], failures: detFails },
        { ok: true, warnings: [], failures: [] },
        { deliveryMethod, guardrailBypass: "deterministic_rejected" },
      );
    }
    ragInfo("guardrails.bypass", { method: "deterministic_trust", deliveryMethod });
    return allowShapeFromModelText(answer, "deterministic_bypass", {
      deliveryMethod,
      guardrailBypass: "deterministic",
    });
  }

  const hallucination = detectHallucinations(answer, retrievalContext);
  const base = validateForProfile(answer, retrievalContext, intent, hints);
  const grounding = validateGrounding(answer, retrievalContext, intent || {}, hints);

  const hardFailureCodes = new Set([
    "parameter_leakage",
    "grounding_antistatic_confusion",
    "safety_extra_reasoning",
    "golden_numeric_mismatch",
    "deterministic_topic_mismatch",
  ]);
  const regenerationHard = (base.failures || []).some((f) => f.code === "regeneration_forbidden_missing");
  const baseHardRaw = (base.failures || []).filter((f) => hardFailureCodes.has(f.code));
  let baseHard = baseHardRaw;
  if (hints.ragPure && hints.equipmentId === "sdb1560m") {
    baseHard = baseHard.filter((f) => f.code !== "golden_numeric_mismatch");
  }
  const groundingHard = (grounding.failures || []).filter((f) => hardFailureCodes.has(f.code));
  const hasHardFailure = baseHard.length > 0 || groundingHard.length > 0;

  const softFailed = base.ok === false || grounding.ok === false;

  if (
    deliveryMethod === "standard" &&
    textPresent &&
    trimmed.length < 20 &&
    !looksLikeAbstainPhrase(trimmed)
  ) {
    ragWarn("guardrails.too_short", { deliveryMethod, textLen: trimmed.length, preview: trimmed.slice(0, 24) });
    return abstainShape("answer_too_short", hallucination, base, grounding, { deliveryMethod });
  }

  if (textPresent && base.ok !== false && grounding.ok !== false && !hallucination.flagged) {
    ragInfo("guardrails.pass_strict", { deliveryMethod, reason: "validation_ok" });
    return allowShapeFromModelText(answer, "guardrails_passed", { deliveryMethod, hallucination, base, grounding });
  }

  if (hasHardFailure) {
    const numHall = [...(base.failures || []), ...(grounding.failures || [])].some(
      (f) => f.code === "parameter_leakage" && f.detail === "numerical_hallucination_detected",
    );
    if (numHall) {
      ragWarn("guardrails.hard_fail", {
        reason: "numerical_hallucination_detected",
        deliveryMethod,
        claims: [...(base.failures || []), ...(grounding.failures || [])]
          .filter((f) => f.detail === "numerical_hallucination_detected")
          .map((f) => f.claim)
          .filter(Boolean),
      });
    } else {
      ragWarn("guardrails.hard_fail", {
        deliveryMethod,
        codes: [...baseHard, ...groundingHard].map((f) => f.code),
      });
    }
    return abstainShape("grounding_failed_hard", hallucination, base, grounding, { deliveryMethod });
  }

  const looksLikeAbstain =
    /информац(?:ия|ии)\s+.*отсутств|не\s+найден|недостаточно\s+данных/i.test(trimmed);
  const substantiveAnswer = trimmed.length >= 48 && !looksLikeAbstain;
  const semanticRescue =
    substantiveAnswer &&
    textPresent &&
    semanticSimilarity >= semanticRescueThreshold &&
    softFailed;

  if (semanticRescue) {
    const skipGoldenRescueBlock =
      hints.ragPure ||
      hints.validationProfile === "sdb1560" ||
      (hints.honestRag && hints.skipGoldenFacts);
    const goldenFail = (base.failures || []).some((f) => f.code === "golden_numeric_mismatch");
    if (goldenFail && !skipGoldenRescueBlock) {
      ragWarn("guardrails.block_semantic_rescue", { reason: "golden_numeric_mismatch", deliveryMethod });
      return abstainShape("golden_numeric_mismatch", hallucination, base, grounding, { deliveryMethod });
    }
    ragInfo("guardrails.semantic_rescue", {
      deliveryMethod,
      semanticSimilarity,
      threshold: semanticRescueThreshold,
      softFailed,
    });
    return allowShapeFromModelText(answer, "semantic_rescue_retrieval_similarity", {
      deliveryMethod,
      hallucination,
      base,
      grounding,
      semanticRescue: true,
    });
  }

  if (isEffectivelyEmptyContext(retrievalContext) && softFailed) {
    ragWarn("guardrails.abstain_empty_context", { deliveryMethod, softFailed });
    return abstainShape("grounding_failed_empty_context", hallucination, base, grounding, { deliveryMethod });
  }

  if (base.ok === false || grounding.ok === false) {
    ragInfo("guardrails.soft_relaxed", { deliveryMethod, baseOk: base.ok, groundingOk: grounding.ok });
    return allowShapeFromModelText(answer, "grounding_soft_relaxed", {
      deliveryMethod,
      hallucination,
      base,
      grounding,
    });
  }

  if (hallucination.flagged) {
    ragInfo("guardrails.hallucination_soft", { deliveryMethod, ratio: hallucination.ratio });
    return allowShapeFromModelText(answer, "hallucination_heuristic_soft_warning", {
      deliveryMethod,
      hallucination,
      base,
      grounding,
    });
  }

  ragInfo("guardrails.pass_default", { deliveryMethod });
  return allowShapeFromModelText(answer, "guardrails_passed", { deliveryMethod, hallucination, base, grounding });
}

module.exports = {
  runGuardrails,
};
