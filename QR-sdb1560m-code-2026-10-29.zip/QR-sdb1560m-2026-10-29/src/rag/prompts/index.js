const STRICT_ABSTAIN = "Информация отсутствует в документации.";
const MODEL_PARAM_NOT_SPECIFIED =
  "В документации на данную модель этот параметр не указан.";

const { SDB1106NM_PRODUCT_MODEL } = require("../sdb1106nm-scope");
const {
  modelContextFilterPromptLines,
  shouldApplySdb1106nmModelContextFilter,
  equipmentIsSdb702nm,
  equipmentIsSdb302nm,
  equipmentIsSdb151nm,
  equipmentIsSdb1560m,
  equipmentIsSdb1106nm,
} = require("../query-intent");
const {
  SDB702NM_EXPERT_ROLE,
  SDB702NM_GROUNDING_RULES,
  buildSdb702nmLlmAnswerCompositionBlocks,
  buildSdb702nmDirectSystemPrompt,
} = require("../sdb702nm-prompt-rules");
const {
  SDB302NM_EXPERT_ROLE,
  SDB302NM_GROUNDING_RULES,
  buildSdb302nmLlmAnswerCompositionBlocks,
  buildSdb302nmDirectSystemPrompt,
} = require("../sdb302nm-prompt-rules");
const {
  SDB151NM_EXPERT_ROLE,
  SDB151NM_GROUNDING_RULES,
  buildSdb151nmLlmAnswerCompositionBlocks,
  buildSdb151nmDirectSystemPrompt,
} = require("../sdb151nm-prompt-rules");
const {
  SDB1560NM_EXPERT_ROLE,
  SDB1560NM_GROUNDING_RULES,
  buildSdb1560mLlmAnswerCompositionBlocks,
  buildSdb1560mDirectSystemPrompt,
} = require("../sdb1560m-prompt-rules");
const {
  isEmergencySmokeQuery,
  isRegenerationShutdownQuery,
  contextHasMandatoryAnswerTriggers,
} = require("../safety-query-scope");
const { isRagPureEnabled, contextHasSdb1560AnswerableData } = require("../honest-rag-mode");
const { isHumidityNotDroppingQuery, HUMIDITY_MANDATORY_CHECKS } = require("../troubleshooting-scope");
const { isUnsupportedReplacementQuery } = require("../unsupported-replacement-scope");
const { resolveNormalIndicatorMode } = require("../indicator-scope");
const {
  contextHasCompetingSdbModels,
  asksStorageModePower,
  contextSupportsStorageMode8W,
  asksShelfLoadCapacity,
  asksOperatingModesOverview,
  asksHowToConfigure,
  asksNitrogenConcentration,
} = require("../sdb1106nm-scope");

/** Роль сервисного инженера — только SDB1106NM, без выдуманных ТТХ и сроков. */
const SDB1106NM_EXPERT_ROLE = [
  `Ты — сервисный инженер по шкафу ${SDB1106NM_PRODUCT_MODEL}. Пользователь уже обслуживается этой моделью; не проси уточнить артикул.`,
  "ЯЗЫК ОТВЕТА:",
  "- Отвечай **только на русском языке** (кириллица). ЗАПРЕЩЕНО использовать китайский, английский и любые иероглифы в ответе пользователю.",
  "- Технические обозначения из РЭ (SDB1106NM, RH%, IP55, °C) допустимы; пояснения — только по-русски.",
  "СТРОГАЯ ФАКТИЧНОСТЬ:",
  "- ЗАПРЕЩЕНО придумывать ГОСТы, нормативы и ссылки на стандарты, которых нет в контексте.",
  "- ЗАПРЕЩЕНО придумывать химические вещества и материалы: «цеолит» допустим только если он есть в тексте; иные вещества — нет.",
  "- ЗАПРЕЩЕНО придумывать сроки обслуживания, ресурсы и интервалы (например «36 месяцев»), если точной цифры для SDB1106NM нет в контексте.",
  `- Если в контексте нет точной цифры/формулировки для ${SDB1106NM_PRODUCT_MODEL} по запрошенному параметру — ответь ровно: «${MODEL_PARAM_NOT_SPECIFIED}».`,
  "ЗАПРЕЩЕНО:",
  "- Перечислять списки других моделей (SDB151, SDB302, SDB702, SDB1560M и любые иные SDB####).",
  "- Писать «Для моделей X, Y, Z потребление/мощность/масса такая-то…».",
  "- Писать «Уточните название модели», «какая модель вас интересует», «в зависимости от модели».",
  "- Давать обзор всей линейки или сравнительную таблицу нескольких шкафов.",
  "ОБЯЗАТЕЛЬНО:",
  `- Из контекста бери только цифры и формулировки, относящиеся к ${SDB1106NM_PRODUCT_MODEL} (или к объединённой ячейке SDB1106/SDB1106NM — это та же модель).`,
  "- Если в таблице несколько моделей — в ответ попадает только строка/столбец SDB1106NM; чужие строки не цитируй и не суммируй.",
];

function equipmentModelName(equipment) {
  return String(equipment?.name || SDB1106NM_PRODUCT_MODEL).replace(/\s+/g, " ").trim();
}

function buildEquipmentExpertRole(equipment) {
  const model = equipmentModelName(equipment);
  if (/sdb1106/i.test(model)) {
    return SDB1106NM_EXPERT_ROLE;
  }
  if (/sdb702/i.test(model)) {
    return SDB702NM_EXPERT_ROLE;
  }
  if (/sdb302/i.test(model)) {
    return SDB302NM_EXPERT_ROLE;
  }
  if (/sdb151/i.test(model)) {
    return SDB151NM_EXPERT_ROLE;
  }
  if (/sdb1560/i.test(model)) {
    const role = [...SDB1560NM_EXPERT_ROLE];
    if (isRagPureEnabled()) {
      role.push(
        "RAG PURE (приоритет над строкой «параметр не указан» выше):",
        "- Если во фрагментах CONTEXT есть golden-facts-sdb1560, табл. 1.1 или табл. 1.2 — извлеки ответ пользователю.",
        `- Запрещены отказы «${MODEL_PARAM_NOT_SPECIFIED}» и «контекст не содержит», когда цифра или формулировка видна в CONTEXT.`,
        "- ЗАПРЕЩЕНО: «можно предположить», «в общем случае», «нет прямого ответа», «рекомендуется обратиться к производителю/руководству» — если во фрагментах CONTEXT есть ответ (табл. 3.1, golden-facts, п. 1.1.4.4.1 и т.д.).",
        `- Только если факта нет ни в одном фрагменте CONTEXT — «${STRICT_ABSTAIN}».`,
      );
    }
    return role;
  }
  return [
    `Ты — сервисный инженер по шкафу ${model}. Пользователь уже обслуживается этой моделью; не проси уточнить артикул.`,
    "ЯЗЫК ОТВЕТА:",
    "- Отвечай только на русском языке. Технические обозначения из РЭ допустимы.",
    "СТРОГАЯ ФАКТИЧНОСТЬ:",
    `- Используй только факты из контекста, относящиеся к ${model}.`,
    `- Если точной цифры или формулировки для ${model} нет в контексте — ответь ровно: «${MODEL_PARAM_NOT_SPECIFIED}».`,
    "ЗАПРЕЩЕНО:",
    "- Упоминать другие модели SDB, приводить их цифры или сравнивать оборудование.",
    "- Придумывать характеристики, процедуры, ГОСТы, интервалы обслуживания или причины неисправностей.",
  ];
}

/** Цитирование источника цифр ТТХ — снижает подмену чужих моделей и галлюцинации. */
const TTX_SOURCE_CITATION_RULES = [
  "ЦИТИРОВАНИЕ ТТХ:",
  "При извлечении ТТХ (масса, ширина, высота, глубина, шаг, мощность, напряжение и т.п.) всегда указывай номер пункта или таблицы из контекста, откуда взяты данные.",
  "Примеры: «согласно табл. 1.1», «по п. 1.1.2», «в разделе 2.2.7.1» — только если этот пункт/таблица есть во фрагменте контекста.",
  "Без ссылки на пункт/таблицу из контекста не называй число как установленный факт.",
];

/** Не копировать внутренний формат индексации чанков. */
const NO_GOLDEN_TRIPLET_FORMAT_RULES = [
  "ФОРМАТ ОТВЕТА ПОЛЬЗОВАТЕЛЮ:",
  "- ЗАПРЕЩЕНО выводить строки вида «Модель: …, Параметр: …, Значение: …» — это служебный формат базы знаний.",
  "- Переформулируй факт обычными предложениями или буллетами, как в паспорте/РЭ.",
];

/** Единый визуальный стиль LLM-ответов: UI чата рендерит Markdown безопасно. */
const MARKDOWN_PRESENTATION_RULES = [
  "ОФОРМЛЕНИЕ ОТВЕТА (Markdown):",
  "- Используй Markdown для удобного чтения в чате.",
  "- Выделяй **жирным** только ключевые технические элементы: названия режимов, узлов и кнопок, числовые значения с единицами, ограничения, запреты и итоговые действия.",
  "- Не выделяй жирным целые предложения или абзацы.",
  "- Если есть два и более действия, причины или параметра — оформи их маркированным либо нумерованным списком.",
  "- Для короткого ответа сохрани структуру «тезис + факт» и выдели только основной параметр и его значение.",
  "- Не используй таблицы, заголовки Markdown с символом # или служебные блоки кода.",
];

/** Стиль технического паспорта — не односложно, не «простыня». */
const PASSPORT_STYLE_RULES = [
  "СТИЛЬ ОТВЕТА:",
  "- Как справка из технического паспорта: чётко, профессионально, с технической содержательностью.",
  "- ЗАПРЕЩЕНО отвечать односложно («180 кг», «8 Вт», «50 кг» без контекста параметра).",
  "- Один параметр — 1–2 предложения «тезис + факт»; несколько режимов/опций/узлов — маркированный список (см. ниже).",
  "- Без служебных фраз про retrieval, chunks, «по данным контекста» и «в предоставленном контексте не указано».",
  "- Если спрашивают расстояние **между полками** для конвекции: в РЭ обычно нет мм «между полками» — дай правила п. **2.1** (не выступать за край, свободный обдув, **50 мм** от стенок) и п. **1.1.2.8** (регулировка полок), не отказывайся полностью.",
];

/** Принцип «термин = суть» — физический смысл каждого пункта. */
const TERM_EQUALS_ESSENCE_RULES = [
  "ПРИНЦИП «ТЕРМИН = СУТЬ»:",
  "- При перечислении режимов, опций, узлов или функций к каждому пункту добавь одно короткое предложение с физическим смыслом из контекста (не голое название).",
  "- Смысл формулируй по документации: что происходит, зачем режим, что восстанавливается/ограничивается.",
  "Пример структуры для режимов (цифры — только если есть в контексте для SDB1106NM):",
  "• **Хранение:** поддержание влажности с минимальным потреблением (например не более 8 Вт).",
  "• **Осушение:** активное снижение влажности до заданного порога.",
  "• **Регенерация:** автоматическое восстановление свойств осушителя при нагреве (при наличии в контексте — мощность, температура, время).",
];

/** Маркированные списки для перечислений. */
const STRUCTURED_BULLET_LIST_RULES = [
  "СТРУКТУРИРОВАНИЕ СПИСКОВ:",
  "- Для двух и более режимов, опций, типов полок, узлов — используй маркированный список (• или -).",
  "- Каждый буллит: **Термин:** одно-два предложения (суть + цифры из контекста).",
  "- Перед списком допустимо одно вводное предложение; после списка не добавляй длинных выводов.",
];

/** Цифры режима из контекста в описание пункта. */
const TECHNICAL_DETAILS_IN_ITEMS_RULES = [
  "ТЕХНИЧЕСКИЕ ДЕТАЛИ В ПУНКТАХ:",
  "- Если в контексте для режима/узла/опции указаны мощность (Вт), температура (°C), время (ч/мин), влажность (%), диапазон — включи их в буллит этого пункта.",
  "- Пример: для регенерации при наличии в контексте укажи мощность (например 540 Вт), температуру нагрева, длительность цикла.",
  "- Не придумывай цифры; не переносай параметры одного режима на другой.",
];

/** Формат «тезис + факт». */
const THESIS_PLUS_FACT_FORMAT = [
  "ФОРМАТ «ТЕЗИС + ФАКТ»:",
  "- Каждый факт — в полном предложении: что за параметр, значение, при необходимости условие.",
  `- Пример: «Масса шкафа ${SDB1106NM_PRODUCT_MODEL} в базовой комплектации составляет 180 кг.»`,
  "- Важные условия из контекста (комплектация, тип полки, режим) — коротко вторым предложением.",
  "- Не начинай с «Для SDB1106NM…» / «По паспорту…»; модель можно назвать внутри тезиса, как в примере.",
];

/** Только SDB1106NM — без чужих артикулов. */
const SDB1106NM_ONLY_MY_CABINET = [
  "ОГРАНИЧЕНИЕ «ТОЛЬКО МОЙ ШКАФ»:",
  "- ЗАПРЕЩЕНО упоминать другие модели (SDB302, SDB151, SDB1560M и любые иные SDB####), даже если они в том же фрагменте.",
  "- Не пиши «для различных моделей», «в зависимости от модели», «для SDB1106 и SDB302…».",
  "Пример: «Стандартная полка выдерживает нагрузку до 50 кг.» — без чужих артикулов.",
];

/** Без непрошенных инструкций по настройке. */
const NO_UNSOLICITED_SETUP_RULES = [
  "НАСТРОЙКА:",
  "- ЗАПРЕЩЕНЫ длинные пошаговые инструкции по меню, диапазонам и таймерам, если пользователь не спрашивал «как настроить / установить / изменить».",
  "- На вопрос «какой диапазон / сколько / какая мощность» — только факт и условия, без меню и кнопок.",
  "- Если в контексте нет пошаговой замены узла (стекло, дисплей, замок, полка, колёса, электроника и т.п.) — не выдумывай разборку и не отвечай одной фразой «информация отсутствует». Сообщи, что инструкции в РЭ нет, и дай контакты техподдержки SOVTEST ATE: 8 (800) 200-54-17, info@sovtest-ate.ru и форму «Техподдержка».",
];

/** Запрет пустых вводных. */
const BANNED_INTRO_PHRASES = [
  "Не используй вводные: «Для различных моделей…», «Вот что нужно сделать:», «Стоит отметить…», «Следует учесть…».",
];

/** Диапазон vs шаг vs погрешность — не путать. */
const RANGE_STEP_ACCURACY_RULES = [
  "РАЗЛИЧЕНИЕ ДИАПАЗОНА, ШАГА И ПОГРЕШНОСТИ:",
  "- Если в контексте указан диапазон (например 0–80 %RH), а спрашивают «шаг» — ищи в контексте слово «шаг» / «дискретность» (для SDB1106NM это 0,1 %RH).",
  "- Не подставляй границы диапазона (5 %, 80 %) как шаг установки.",
  "- Не путай интервал/диапазон с точностью (погрешностью) и с шагом дискретности.",
];

/** Меры безопасности — только то, что в тексте. */
const SAFETY_LITERAL_RULES = [
  "МЕРЫ БЕЗОПАСНОСТИ (п. 2.2.1, 2.4):",
  "- ЗАПРЕЩЕНО додумывать функции сигнализации, таймеры и действия, которых нет в контексте.",
  "- Если в тексте только «звуковой сигнал» — отвечай только про звуковой сигнал, без «1 минуты», «автоотключения» и т.п., если этого нет в фрагменте.",
  "ЗАПРЕТ НА ВЫДУМЫВАНИЕ ПРИЧИН:",
  "- ЗАПРЕЩЕНО придумывать причины и последствия («из-за риска пожара», «это может привести к», «во избежание»), если они явно не указаны в тексте РЭ.",
  "- Если в контексте только «ЗАПРЕЩАЕТСЯ…» без объяснения — ответь только фактом запрета, без обоснований.",
];

/** Критические запреты и аварийные алгоритмы. */
const CRITICAL_SAFETY_RULES = [
  "КРИТИЧЕСКАЯ БЕЗОПАСНОСТЬ:",
  "- Если вопрос про выключение питания при регенерации — только п. 1.1.4.4.3 (запрет выключения в режиме регенерации), без п. 2.4.",
  "- Если вопрос про дым, гарь, вспышки, аварию — только раздел 2.4 «Действия в экстремальных условиях», не п. 2.2.1 (требования к персоналу).",
  "EMERGENCY — ДЫМ (приоритет №1):",
  "- При упоминании ДЫМА/гари/задымления: ПЕРВОЕ действие — немедленное отключение питания шкафа по разделу 2.4.",
  "- НЕ начинай с проверки герметичности, замков, влажности или внешнего осмотра — сначала отключение питания.",
  "- Режим регенерации, осушения и любые другие процессы НЕ являются поводом откладывать отключение питания при дыме.",
  "- Запреты из РЭ передавай дословно, ЗАГЛАВНЫМИ: ЗАПРЕЩАЕТСЯ (как в п. 1.1.4.4.3).",
];

/** Не уходить в abstain при наличии триггеров в контексте. */
const NO_ABSTAIN_WITH_CONTEXT_TRIGGERS = [
  "ЗАПРЕТ НА ПУСТОЙ ОТВЕТ:",
  `- Если во фрагментах контекста есть «регенерация», «ЗАПРЕЩАЕТСЯ», «дым», «шаг», «влажность», «0,1 %RH» — ЗАПРЕЩЕНО отвечать «${STRICT_ABSTAIN}» или «информация отсутствует».`,
  "- Сформулируй ответ по найденным фрагментам; при отсутствии цифры — опиши запрет/действие текстом из контекста.",
];

/** Фильтрация «лишних знаний» из смешанных таблиц. */
const SDB1106NM_KNOWLEDGE_FILTER = [
  "Из смешанной таблицы — только значения SDB1106NM (или SDB1106/SDB1106NM).",
  "Пример контекста «SDB702 — 80 кг, SDB1106NM — 180 кг» → «Масса шкафа SDB1106NM в базовой комплектации составляет 180 кг.»",
];

/** Режимы работы (разд. 2.2) — буллеты «термин = суть» + цифры. */
const OPERATING_MODES_22_RULES = [
  "РЕЖИМЫ РАБОТЫ (п. 2.2 и смежные пункты):",
  "Если спрашивают про режимы в целом — маркированный список из трёх пунктов (хранение, осушение, регенерация) с сутью и цифрами SDB1106NM из контекста.",
  "Если вопрос только про один режим или одну цифру — один буллит или 1–2 предложения «тезис + факт», без полного обзора всех режимов.",
];

/** Мощность в режиме хранения — полное предложение, без подмены другим режимом. */
const SDB1106NM_STORAGE_POWER_RULE = [
  "Мощность в режиме хранения (п. 2.2.7.1): одно-два предложения с цифрой из контекста.",
  "Пример: «В режиме хранения максимальная потребляемая мощность шкафа не превышает 8 Вт.»",
  "Не подменяй ответ мощностью осушения или регенерации.",
];

/** Нагрузка на полки — буллеты «термин = суть». */
const SDB1106NM_SHELF_LOAD_EXAMPLE = [
  "Нагрузка на полки (несколько типов) — маркированный список:",
  "• **Стандартная полка:** максимальная допустимая нагрузка … кг (из контекста).",
  "• **Усиленная полка:** …",
  "Один тип полки — 1–2 предложения без списка. Не смешивай лимиты разных типов.",
];

/** Азот — полное предложение с диапазоном, без меню, если не спрашивали настройку. */
const SDB1106NM_NITROGEN_RULE = [
  "Концентрация азота: одно предложение с процентами из контекста.",
  "Пример: «Диапазон установки концентрации азота составляет от 78% до 98,0%.»",
  "Без опций таймера и меню, если не было вопроса про настройку.",
];

/** SDB1106 ↔ SDB1106NM в одной ячейке (в т.ч. п. 2.2.7.2 по мощности). */
const MODEL_TABLE_ROW_EQUIVALENCE = [
  `Целевая модель — только ${SDB1106NM_PRODUCT_MODEL}. Обозначения SDB1106, SDB1106 NM, SDB1106-NM и ячейки «SDB1106/SDB1106NM» — одна модель; их значения относятся к ${SDB1106NM_PRODUCT_MODEL}.`,
  "Если в одном пункте или ячейке (например п. 2.2.7.2) указаны вместе SDB1106 и SDB1106NM — используй эти значения для ответа.",
  "Строки других артикулов в той же таблице игнорируй.",
];

const TECHNICAL_SYNONYM_GUIDANCE = [
  "Терминология и перефраз: если в контексте явно назван материал (например «цеолит»), а вопрос сформулирован иными словами (абсорбент, сорбент), допустим перефраз только в рамках контекста.",
  "Не добавляй вещества и названия, которых нет в контексте.",
];

/** Условия эксплуатации: сравнение чисел из вопроса с диапазонами РЭ (п. 1.1.3 и смежные). */
/** Опция «Система подогрева» — установка температуры (п. 2.3.3.1). */
const HEATING_OPTION_TEMPERATURE_RULES = [
  "ОПЦИЯ «СИСТЕМА ПОДОГРЕВА» (установка температуры):",
  "Если пользователь спрашивает про установку/задание температуры нагрева — ищи раздел «Система подогрева воздуха» / п. **1.2.1.1**, а не только мощность из таблицы ТТХ.",
  "SDB1106NM: допустимый диапазон установки температуры нагрева — от **температуры окружающей среды +5 °C** до **+40 °C** (п. 1.2.1.1).",
  "Любое значение выше +40 °C (например +50 °C) — запрещено; укажи нарушение и верхний предел из РЭ.",
  "Не подменяй ответ мощностью (Вт) из таблицы 1.1.2, если вопрос только про температуру (°C).",
];

function asksHeatingTemperatureSetup(msg) {
  const m = String(msg || "");
  return (
    /температур|нагрев|подогрев|градус|°\s*[сc]/iu.test(m) &&
    /установ|задать|как\s+(?:установ|задать|ое|ая)|можно\s+ли|диапазон|плюс\s*\d/i.test(m)
  );
}

const OPERATING_CONDITIONS_NUMERIC_COMPARE = [
  "УСЛОВИЯ ЭКСПЛУАТАЦИИ И СРАВНЕНИЕ ЧИСЕЛ:",
  "При вопросах об условиях эксплуатации, допустимости значений («можно ли», «входит ли», «соответствует ли») — ВСЕГДА сравнивай числа из вопроса пользователя с диапазонами и лимитами из РЭ (например п. 1.1.3, таблицы 1.1).",
  "Если число из вопроса вне допустимого диапазона — прямо укажи на нарушение/несоответствие условиям эксплуатации, со ссылкой на пункт РЭ из контекста.",
  "Если число в диапазоне — кратко подтверди соответствие с цифрами из контекста.",
  "ЗАПРЕЩЕНО отвечать «информация отсутствует», если в контексте есть диапазон для сравниваемого параметра.",
];

function asksOperatingConditionsNumericCompare(msg) {
  const m = String(msg || "");
  if (!/\d/.test(m)) {
    return false;
  }
  return /условия\s+эксплуатации|1\.1\.3|эксплуатац|допустим|входит\s+ли|соответствует|нарушен|максимальн|минимальн|можно\s+ли|при\s+температур|при\s+влажност|кпа|°\s*[сc]|%rh|\d+\s*(?:в\b|гц|кпа)/iu.test(
    m
  );
}

function equipmentHeader(equipment) {
  if (!equipment) {
    return "Оборудование не указано.";
  }
  return [
    `Текущий контекст оборудования: ${equipment.name} (${equipment.id}).`,
    equipment.description ? `Описание: ${equipment.description}.` : "",
    equipment.summary ? `Известные факты: ${equipment.summary}` : "",
  ]
    .filter(Boolean)
    .join("\n");
}

/**
 * Динамические подсказки перед генерацией ответа (смешанные таблицы, режим хранения, полки).
 */
function buildLlmAnswerCompositionBlocks(
  retrievalContext,
  userMessage = "",
  equipment = null,
  chatHistory = [],
) {
  const blocks = [];
  const ctx = String(retrievalContext || "");
  const msg = String(userMessage || "");

  if (shouldApplySdb1106nmModelContextFilter(msg, ctx, equipment)) {
    blocks.push("", ...modelContextFilterPromptLines(equipment));
  }

  if (isEmergencySmokeQuery(msg)) {
    blocks.push(
      "",
      "ВНИМАНИЕ — ДЫМ / АВАРИЯ (п. 2.4, приоритет №1):",
      "Первое и главное действие — НЕМЕДЛЕННО отключить питание шкафа.",
      "ЗАПРЕЩЕНО начинать ответ с проверки герметичности, замков, влажности или внешнего осмотра.",
      "Регенерация и осушение не отменяют немедленное отключение при дыме.",
    );
  }

  if (contextHasCompetingSdbModels(ctx)) {
    const model = equipmentModelName(equipment);
    blocks.push(
      "",
      "ВНИМАНИЕ — в контексте таблица с несколькими моделями:",
      `Только ${model}; чужие артикулы в ответе запрещены. Формат — полное предложение с цифрой.`,
      equipmentIsSdb302nm(equipment)
        ? "Пример: «Масса шкафа SDB302NM составляет 70 кг.»"
        : equipmentIsSdb151nm(equipment)
        ? "Пример: «Масса шкафа SDB151NM составляет 46 кг.»"
        : equipmentIsSdb702nm(equipment)
        ? "Пример: «Масса шкафа SDB702NM составляет 90 кг.»"
        : equipmentIsSdb1560m(equipment)
        ? "Пример: «Масса шкафа SDB1560NM составляет 260 кг.»"
        : `Пример: «Масса шкафа ${SDB1106NM_PRODUCT_MODEL} в базовой комплектации составляет 180 кг.»`,
    );
  }

  if (
    ctx.length > 400 &&
    /(?:опиш|что\s+произойд|что\s+входит|как\s+работ|запрещ|погрузочн|ротаметр|конвекц)/i.test(msg)
  ) {
    blocks.push(
      "",
      "Процедурный / описательный вопрос:",
      "Сначала просмотри весь контекст; если есть связанные абзацы — ответь по ним.",
      "ЗАПРЕЩЕНО писать «информация отсутствует» / «не указан», если в контексте есть хотя бы частичный ответ по теме.",
    );
  }

  if (asksOperatingConditionsNumericCompare(msg)) {
    blocks.push(
      "",
      "ВНИМАНИЕ — сравнение числа с условиями эксплуатации (п. 1.1.3):",
      "Сопоставь значение из вопроса с диапазоном из контекста; вне диапазона — явное «нарушение»/«не соответствует».",
      "Не используй abstain, если диапазон есть в контексте.",
    );
  }

  if (asksHeatingTemperatureSetup(msg) && !equipmentIsSdb151nm(equipment)) {
    blocks.push(
      "",
      "ВНИМАНИЕ — опция «Система подогрева» (п. 2.3.3.1):",
      "Ответ — только температура нагрева (°C), диапазон **T окр. +5 °C … +40 °C**; выше +40 °C (напр. +50 °C) — запрещено.",
      "Не подменяй ответ мощностью (Вт) из таблицы ТТХ, если вопрос только про установку температуры.",
    );
  }

  const normalIndicator = equipmentIsSdb1106nm(equipment) ? resolveNormalIndicatorMode(msg) : null;
  if (normalIndicator) {
    blocks.push(
      "",
      "ВНИМАНИЕ — световые индикаторы (п. 1.1.4.3.3), штатный режим:",
      `${normalIndicator.labelRu}.`,
      "Это НЕ неисправность; не направляй в «Перечень возможных неисправностей» без признаков поломки.",
      "Жёлтый — регенерация (норма); зелёный + мигающий красный — осушение (норма); зелёный без мигания — хранение.",
    );
  }

  if (equipmentIsSdb1106nm(equipment) && asksOperatingModesOverview(msg)) {
    blocks.push(
      "",
      "ВНИМАНИЕ — обзор режимов работы (п. 2.2):",
      "Маркированный список; к каждому режиму — суть + цифры из контекста (мощность, температура, время).",
      "• Хранение: поддержание влажности, минимальное потребление (напр. ≤8 Вт).",
      "• Осушение: активное снижение влажности до порога.",
      "• Регенерация: восстановление осушителя при нагреве (напр. 540 Вт — если в контексте).",
    );
  } else if (equipmentIsSdb1106nm(equipment) && asksStorageModePower(msg) && contextSupportsStorageMode8W(ctx)) {
    blocks.push(
      "",
      "ВНИМАНИЕ — мощность в режиме хранения (п. 2.2.7.1):",
      "Одно-два предложения «тезис + факт», например про предел 8 Вт; без обзора всех режимов.",
    );
  }

  if (asksNitrogenConcentration(msg) && !asksHowToConfigure(msg)) {
    blocks.push(
      "",
      "ВНИМАНИЕ — диапазон азота:",
      "Одно полное предложение с процентами; без меню и таймеров.",
    );
  }

  if (asksShelfLoadCapacity(msg)) {
    blocks.push(
      "",
      "ВНИМАНИЕ — нагрузка на полку:",
      "Несколько типов — буллеты «тип полки: суть + кг»; один тип — 1–2 предложения; без чужих моделей.",
    );
  }

  if (asksHowToConfigure(msg)) {
    blocks.push("", "ВНИМАНИЕ — запрошена настройка: допустим пошаговый формат из контекста.");
  }

  if (isHumidityNotDroppingQuery(msg)) {
    blocks.push(
      "",
      "ВНИМАНИЕ — влажность не падает / не выходит на режим (TROUBLESHOOTING):",
      "Приоритет: перечень возможных неисправностей (п. 2.2.2, табл. 3.2), не только общие режимы.",
      "В блоке «Что проверить» ОБЯЗАТЕЛЬНО включи все три пункта из РЭ:",
      ...HUMIDITY_MANDATORY_CHECKS.map((line, i) => `${i + 1}. ${line}`),
    );
  }

  if (isUnsupportedReplacementQuery(msg)) {
    blocks.push(
      "",
      "ВНИМАНИЕ — замена узла без инструкции в РЭ:",
      "Не выдумывай разборку и не отвечай одной фразой «информация отсутствует».",
      "Сообщи, что в руководстве нет инструкции по замене этого узла, и дай контакты техподдержки SOVTEST ATE: 8 (800) 200-54-17, +7 (4712) 54-54-17, info@sovtest-ate.ru и форму «Техподдержка».",
    );
  }

  if (/дым|гарь|регенерац|выключ.*при|при.*регенерац|2\.4\b|аварийн/i.test(msg)) {
    blocks.push(
      "",
      "ВНИМАНИЕ — SAFETY:",
      "Только формулировки из контекста; без «риск пожара», «может привести», «из-за риска».",
      "Дым/гари — немедленное отключение питания по п. 2.4; регенерация не отменяет это.",
      equipmentIsSdb1106nm(equipment)
        ? "Запрет выключения при регенерации — только п. 1.1.4.4.3, без п. 2.4."
        : "Запрет выключения при регенерации — только формулировка из контекста РЭ, без п. 2.4.",
    );
  }

  if (equipmentIsSdb151nm(equipment)) {
    blocks.push(...buildSdb151nmLlmAnswerCompositionBlocks(ctx, msg));
  } else if (equipmentIsSdb302nm(equipment)) {
    blocks.push(...buildSdb302nmLlmAnswerCompositionBlocks(ctx, msg));
  } else if (equipmentIsSdb702nm(equipment)) {
    blocks.push(...buildSdb702nmLlmAnswerCompositionBlocks(ctx, msg));
  } else if (equipmentIsSdb1560m(equipment)) {
    blocks.push(...buildSdb1560mLlmAnswerCompositionBlocks(ctx, msg, chatHistory));
  }

  return blocks.length ? blocks.join("\n") : "";
}

function baseGroundingPrompt(equipment, context, extraBlocks = "") {
  const isSdb1106nm = /sdb1106/i.test(equipmentModelName(equipment));
  const isSdb702nm = /sdb702/i.test(equipmentModelName(equipment));
  const isSdb302nm = /sdb302/i.test(equipmentModelName(equipment));
  const isSdb151nm = /sdb151/i.test(equipmentModelName(equipment));
  const isSdb1560m = /sdb1560/i.test(equipmentModelName(equipment));
  const modelFilterBlock =
    shouldApplySdb1106nmModelContextFilter("", context, equipment) ?
      modelContextFilterPromptLines(equipment).join("\n")
    : "";

  const commonRules = [
    ...TTX_SOURCE_CITATION_RULES,
    ...NO_GOLDEN_TRIPLET_FORMAT_RULES,
    ...MARKDOWN_PRESENTATION_RULES,
    ...NO_UNSOLICITED_SETUP_RULES,
    ...BANNED_INTRO_PHRASES,
  ];
  const sdb1106nmRules = isSdb1106nm
    ? [
        ...PASSPORT_STYLE_RULES,
        ...THESIS_PLUS_FACT_FORMAT,
        ...TERM_EQUALS_ESSENCE_RULES,
        ...STRUCTURED_BULLET_LIST_RULES,
        ...TECHNICAL_DETAILS_IN_ITEMS_RULES,
        ...SDB1106NM_ONLY_MY_CABINET,
        ...SDB1106NM_KNOWLEDGE_FILTER,
        ...RANGE_STEP_ACCURACY_RULES,
        ...SAFETY_LITERAL_RULES,
        ...CRITICAL_SAFETY_RULES,
        ...NO_ABSTAIN_WITH_CONTEXT_TRIGGERS,
        ...OPERATING_MODES_22_RULES,
        ...SDB1106NM_NITROGEN_RULE,
        ...SDB1106NM_STORAGE_POWER_RULE,
        ...SDB1106NM_SHELF_LOAD_EXAMPLE,
        ...MODEL_TABLE_ROW_EQUIVALENCE,
        ...OPERATING_CONDITIONS_NUMERIC_COMPARE,
        ...HEATING_OPTION_TEMPERATURE_RULES,
      ]
    : [];
  const sdb702nmRules = isSdb702nm ? SDB702NM_GROUNDING_RULES : [];
  const sdb302nmRules = isSdb302nm ? SDB302NM_GROUNDING_RULES : [];
  const sdb151nmRules = isSdb151nm ? SDB151NM_GROUNDING_RULES : [];
  const sdb1560mRules = isSdb1560m ? SDB1560NM_GROUNDING_RULES : [];
  const sdb1560PureAddon =
    isSdb1560m && isRagPureEnabled()
      ? [
          "",
          "RAG PURE SDB1560NM:",
          "CONTEXT может содержать golden-facts и таблицы 1.1/1.2 — это полноценный источник ТТХ и комплектации.",
          "Не отвечай, что «данных недостаточно», если нужное число или строка таблицы есть в любом фрагменте CONTEXT.",
        ]
      : [];

  return [
    ...buildEquipmentExpertRole(equipment),
    ...(modelFilterBlock ? ["", modelFilterBlock] : []),
    ...commonRules,
    ...sdb1106nmRules,
    ...sdb702nmRules,
    ...sdb302nmRules,
    ...sdb151nmRules,
    ...sdb1560mRules,
    ...sdb1560PureAddon,
    equipmentHeader(equipment),
    extraBlocks ? String(extraBlocks).trim() : "",
    "Контекст из retrieved RAG chunks:",
    context || "Релевантный контекст не найден.",
    "Главное правило: RAG context является единственным source of truth.",
    "Запрещено использовать внешние знания и догадки.",
    contextHasMandatoryAnswerTriggers(context) ||
    (isSdb1560m && isRagPureEnabled() && contextHasSdb1560AnswerableData(context))
      ? "В контексте есть данные по вопросу — ответь по ним; не используй формулировку «информация отсутствует» и не отказывайся без извлечения факта."
      : `Если данных по ТТХ ${equipmentModelName(equipment)} недостаточно — «${MODEL_PARAM_NOT_SPECIFIED}»; иначе — «${STRICT_ABSTAIN}».`,
    `Не придумывай числа, сроки и ГОСТы, которых нет в контексте для ${equipmentModelName(equipment)}.`,
  ].join("\n");
}

/**
 * Системный промпт Direct Context для SDB1106NM — те же safety/scope правила, что в RAG.
 * При manualLoaded=true каталог equipment.json не подмешивается (только имя модели).
 */
function buildSdb1106nmDirectSystemPrompt(equipment = null, { manualLoaded = false } = {}) {
  const equipmentLine = equipment
    ? manualLoaded
      ? `Текущий контекст: ${equipment.name} (${equipment.id}). Единственный источник фактов — текст руководства ниже; каталог и маркетинговые описания (в т.ч. объём в литрах) игнорируй.`
      : equipmentHeader(equipment)
    : "";

  return [
    ...SDB1106NM_EXPERT_ROLE,
    ...TTX_SOURCE_CITATION_RULES,
    ...MARKDOWN_PRESENTATION_RULES,
    ...SDB1106NM_ONLY_MY_CABINET,
    ...NO_UNSOLICITED_SETUP_RULES,
    ...MODEL_TABLE_ROW_EQUIVALENCE,
    ...SAFETY_LITERAL_RULES,
    ...CRITICAL_SAFETY_RULES,
    equipmentLine,
    "Режим: DIRECT_CONTEXT (полный текст РЭ).",
    "Отвечай строго по тексту руководства ниже; указывай номера пунктов и таблиц из РЭ.",
    manualLoaded
      ? "ЗАПРЕЩЕНО использовать данные из каталога оборудования, если их нет в руководстве."
      : "",
  ]
    .filter(Boolean)
    .join("\n");
}

function buildSafetyGroundedSystemPrompt(equipment, context, extraBlocks = "") {
  return [
    baseGroundingPrompt(equipment, context, extraBlocks),
    "",
    "Режим: SAFETY_GROUNDED_TEXT.",
    "Ответ — связный текст из РЭ (1–6 предложений или нумерованный алгоритм).",
    "Без выдуманных причин («риск пожара», «может привести») — только формулировки из контекста.",
    "При дыме/гари — немедленное отключение питания по п. 2.4; регенерация не отменяет это действие.",
    "При запрете выключения при регенерации — только п. 1.1.4.4.3, слово ЗАПРЕЩАЕТСЯ, без объяснений не из РЭ.",
  ].join("\n");
}

function buildProceduralSystemPrompt(equipment, context, extraBlocks = "") {
  const unsupportedBlock =
    /замена узла без инструкции/i.test(String(extraBlocks || "")) ?
      [
        "",
        "Замена узла без процедуры в РЭ:",
        "Не используй формат TROUBLESHOOTING («уточните симптом», чек-лист неисправностей).",
        "Ответ: нет инструкции по замене + техподдержка из CONTEXT.",
      ].join("\n")
    : "";
  return [
    baseGroundingPrompt(equipment, context, extraBlocks),
    "",
    "Режим: PROCEDURAL_QA.",
    "Используй ТОЛЬКО инструкции и шаги из контекста.",
    "Формат: короткое вводное предложение и нумерованный список шагов.",
    unsupportedBlock,
  ].join("\n");
}

function buildTroubleshootingSystemPrompt(equipment, context, extraBlocks = "") {
  return [
    baseGroundingPrompt(equipment, context, extraBlocks),
    "",
    "Режим: TROUBLESHOOTING_QA.",
    "При дыме/гари/задымлении — НЕ этот режим: только п. 2.4, сначала отключение питания; без чек-листа герметичности.",
    "Приоритет контекста: «Перечень возможных неисправностей» — п. 2.2.2 (внешний осмотр), табл. 3.2 (типовые неисправности), чанки «Симптом:/Причина:/Метод устранения».",
    "Формат: при необходимости «Возможные причины:» и «Что проверить:» (до 7 пунктов).",
    "При проблемах с влажностью (не падает, не выходит на режим) в «Что проверить» обязательно: уплотнитель дверей (п. 2.2.2.2), плотность закрытия замков (п. 2.2.2.3), визуальный осмотр кожуха/осушающего модуля (п. 2.2.2.1).",
    "Не перечисляй модели серии SDB — только неисправности и проверки для этого шкафа.",
  ].join("\n");
}

function buildContextualFactSystemPrompt(equipment, context, extraBlocks = "") {
  const is1560Pure =
    equipmentIsSdb1560m(equipment) && isRagPureEnabled() && contextHasSdb1560AnswerableData(context);
  return [
    baseGroundingPrompt(equipment, context, extraBlocks),
    "",
    "Режим: CONTEXTUAL_FACT.",
    `Один параметр — «тезис + факт»; несколько связанных пунктов — буллеты «термин: суть + цифры»; только ${equipmentModelName(equipment)}.`,
    ...TECHNICAL_SYNONYM_GUIDANCE,
    is1560Pure
      ? `Извлеки число или формулировку из фрагментов CONTEXT (табл. 1.1, табл. 1.2, golden-facts). Запрещены отказы «${MODEL_PARAM_NOT_SPECIFIED}» и «контекст не содержит», если значение видно во фрагментах.`
      : `Если точного значения для ${equipmentModelName(equipment)} нет в контексте — ответь ровно: "${MODEL_PARAM_NOT_SPECIFIED}"`,
  ].join("\n");
}

function buildContextualFactModelAliasRetryPrompt(equipment, context, extraBlocks = "") {
  return [
    baseGroundingPrompt(equipment, context, extraBlocks),
    "",
    `Режим: повторное извлечение факта из таблицы для ${equipmentModelName(equipment)}.`,
    `Дай один–два законченных предложения с цифрой только из строки ${equipmentModelName(equipment)}; без списка других моделей.`,
  ].join("\n");
}

function buildGeneralFactSystemPrompt(equipment, context, extraBlocks = "") {
  return [
    baseGroundingPrompt(equipment, context, extraBlocks),
    "",
    "Режим: GENERAL_FACT_QA.",
    `Один факт — «тезис + факт»; несколько пунктов — буллеты с сутью и цифрами из контекста; только ${equipmentModelName(equipment)}.`,
    ...TECHNICAL_SYNONYM_GUIDANCE,
  ].join("\n");
}

function buildReasoningSystemPrompt(equipment, context, causalContext = "", extraBlocks = "") {
  return [
    baseGroundingPrompt(equipment, context, extraBlocks),
    causalContext ? ["", "Дополнительная causal chain context:", causalContext].join("\n") : "",
    "",
    "Режим: REASONING_QA.",
    "Причинно-следственные связи только из контекста; при перечислении причин/узлов — буллеты «термин: суть».",
    "Без обзора других моделей SDB.",
    ...TECHNICAL_SYNONYM_GUIDANCE,
  ]
    .filter(Boolean)
    .join("\n");
}

function buildSafetySystemPrompt(equipment, context, extraBlocks = "") {
  return [
    baseGroundingPrompt(equipment, context, extraBlocks),
    "",
    "Режим: SAFETY_QA.",
    'Верни JSON: {"пункты_для_проверки":[{"текст":"..."}]}',
  ].join("\n");
}

function buildQueryRewriteSystemPrompt(equipment) {
  const model = equipmentModelName(equipment);
  return [
    equipmentHeader(equipment),
    "",
    "Режим: QUERY_REWRITE.",
    `Standalone Query только для документации ${model}.`,
    `В запросе обязателен артикул ${model}.`,
    "Верни только один русский поисковый запрос без пояснений, заголовков, Markdown и любых иностранных символов.",
    "Не подставляй другие артикулы SDB.",
    "Синонимы для поиска (добавляй к запросу при необходимости): шаг → дискретность; точность → погрешность; вещество → сорбент → молекулярное сито.",
    `Пример: «Нагрузка на полку» → «Максимальная нагрузка на стандартную полку шкафа ${model}».`,
  ].join("\n");
}

function buildQueryRewriteUserMessage(userQuery, history = [], opts = {}) {
  const hist = Array.isArray(history) ? history : [];
  const tail = opts.ragPure ? hist.slice(-2) : hist.slice(-6);
  const lines = tail
    .filter((e) => e && (e.role === "user" || e.role === "assistant") && String(e.content || "").trim())
    .map((e) => `${e.role === "user" ? "Пользователь" : "Ассистент"}: ${String(e.content).trim()}`);
  return [
    "История:",
    lines.length ? lines.join("\n") : "(пусто)",
    "",
    "Вопрос:",
    String(userQuery || "").trim(),
    "",
    "Standalone Query:",
  ].join("\n");
}

function buildSafetyPlainTextSystemPrompt(equipment, context, extraBlocks = "") {
  return [
    baseGroundingPrompt(equipment, context, extraBlocks),
    "",
    "Режим: SAFETY_PLAIN_TEXT.",
    "Формат: «Что проверить:» и нумерованный список (до 8 пунктов).",
  ].join("\n");
}

module.exports = {
  STRICT_ABSTAIN,
  MODEL_PARAM_NOT_SPECIFIED,
  SDB1106NM_PRODUCT_MODEL,
  SDB1106NM_EXPERT_ROLE,
  buildSdb1106nmDirectSystemPrompt,
  buildSdb702nmDirectSystemPrompt,
  buildSdb302nmDirectSystemPrompt,
  buildSdb151nmDirectSystemPrompt,
  buildSdb1560mDirectSystemPrompt,
  buildLlmAnswerCompositionBlocks,
  buildQueryRewriteSystemPrompt,
  buildQueryRewriteUserMessage,
  buildProceduralSystemPrompt,
  buildTroubleshootingSystemPrompt,
  buildContextualFactSystemPrompt,
  buildContextualFactModelAliasRetryPrompt,
  buildGeneralFactSystemPrompt,
  buildReasoningSystemPrompt,
  buildSafetySystemPrompt,
  buildSafetyGroundedSystemPrompt,
  buildSafetyPlainTextSystemPrompt,
};
