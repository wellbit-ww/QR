﻿# РђСЂС…РёРІ РїРёР»РѕС‚Р° SDB1560M (RAG PURE)

РЎСЂРµР· СЂРµРїРѕР·РёС‚РѕСЂРёСЏ РґР»СЏ РїСЂРѕСЃРјРѕС‚СЂР° СЂРµР°Р»РёР·Р°С†РёРё **SDB1560M**: honest RAG, grounding contract, golden/PDF, С‚РµСЃС‚С‹.

- Р—Р°РїСѓСЃРє: СЃРј. `docs/RUNBOOK_EQUIPMENT_PORTAL.md`, `.env.example` (`RAG_HONEST_EQUIPMENT=sdb1560m`, `RAG_PURE=1`).
- РўРµСЃС‚С‹: `npm run test:sdb1560m:live-regression`, `test:sdb1560m:ad-hoc-probe`.
- РџРѕР»РЅС‹Р№ РјРѕРЅРѕСЂРµРїРѕР·РёС‚РѕСЂРёР№ СЃ РґСЂСѓРіРёРјРё РјРѕРґРµР»СЏРјРё (702, 1106вЂ¦) РІ СЌС‚РѕС‚ Р°СЂС…РёРІ **РЅРµ** РІС…РѕРґРёС‚.

РЎРѕР±СЂР°РЅРѕ: 2026-10-29
